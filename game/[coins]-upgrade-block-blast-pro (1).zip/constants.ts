import { BlockShape, BlockStyle, Quest, QuestType } from './types';

export const GRID_SIZE = 8;
export const INITIAL_BOMB_TIMER = 9;
export const DAILY_LOGIN_REWARD = 100;
export const REVIVE_COST = 50;
export const COINS_PER_100_SCORE = 2;

// --- Styles ---

export const STYLES: Record<string, BlockStyle> = {
  'default': {
    id: 'default',
    name: 'Классика',
    price: 0,
    description: 'Стандартный яркий стиль',
    previewColor: '#3b82f6',
    palette: [
      '#ef4444', // red-500
      '#f97316', // orange-500
      '#eab308', // yellow-500
      '#22c55e', // green-500
      '#06b6d4', // cyan-500
      '#3b82f6', // blue-500
      '#a855f7', // purple-500
      '#ec4899', // pink-500
    ]
  },
  'gold': {
    id: 'gold',
    name: 'Роскошь',
    price: 50, // Debug price (was 500)
    description: 'Премиальный золотой стиль',
    previewColor: '#d97706',
    palette: [
      '#78350f', // amber-900
      '#92400e', // amber-800
      '#b45309', // amber-700
      '#d97706', // amber-600
      '#f59e0b', // amber-500
      '#fbbf24', // amber-400
      '#fcd34d', // amber-300
      '#451a03', // amber-950
    ]
  }
};

// --- Quests ---

export const QUEST_TEMPLATES: Omit<Quest, 'current' | 'claimed'>[] = [
  { id: 'q1', type: QuestType.PLAY_GAMES, target: 3, reward: 50, description: 'Сыграть 3 игры' },
  { id: 'q2', type: QuestType.SCORE_POINTS, target: 1000, reward: 100, description: 'Набрать 1000 очков' },
  { id: 'q3', type: QuestType.CLEAR_LINES, target: 20, reward: 75, description: 'Очистить 20 линий' },
];

// --- Shapes ---

// Definition of shapes as boolean matrices
const RAW_SHAPES: number[][][] = [
  [[1]], // Dot
  [[1, 1]], // 2-Line H
  [[1], [1]], // 2-Line V
  [[1, 1, 1]], // 3-Line H
  [[1], [1], [1]], // 3-Line V
  [[1, 1, 1, 1]], // 4-Line H
  [[1], [1], [1], [1]], // 4-Line V
  [[1, 1], [1, 1]], // Square
  [[1, 0], [1, 0], [1, 1]], // L
  [[0, 1], [0, 1], [1, 1]], // J
  [[1, 1, 1], [0, 1, 0]], // T
  [[1, 1, 0], [0, 1, 1]], // Z
  [[0, 1, 1], [1, 1, 0]], // S
  [[1, 1], [1, 0]], // Small corner
  [[1, 1], [0, 1]], // Small corner inv
  [[1, 0, 0], [1, 0, 0], [1, 1, 1]], // Big L
];

export const generateRandomBlock = (palette: string[] = STYLES['default'].palette): BlockShape => {
  const shapeIdx = Math.floor(Math.random() * RAW_SHAPES.length);
  const colorIdx = Math.floor(Math.random() * palette.length);
  return {
    id: Math.random().toString(36).substr(2, 9),
    matrix: RAW_SHAPES[shapeIdx],
    color: palette[colorIdx],
  };
};