export type Cell = {
  filled: boolean;
  color: string;
  id?: string; // unique id for animation keys
  isBomb?: boolean;
  bombTimer?: number;
} | null;

export type GridType = Cell[][];

export type ShapeDefinition = number[][]; // 0 or 1 matrix

export type BlockShape = {
  id: string;
  matrix: ShapeDefinition;
  color: string;
};

export enum GameMode {
  CLASSIC = 'CLASSIC',
  ADVENTURE = 'ADVENTURE',
}

export enum GameState {
  MENU = 'MENU',
  PLAYING = 'PLAYING',
  PAUSED = 'PAUSED',
  GAME_OVER = 'GAME_OVER',
}

export interface SoundManager {
  playPop: () => void;
  playClear: (combo: number) => void;
  playGameOver: () => void;
  playClick: () => void;
  toggleMute: () => void;
  isMuted: boolean;
}

// --- Economy & Customization Types ---

export interface BlockStyle {
  id: string;
  name: string;
  price: number;
  palette: string[]; // Array of hex colors
  description: string;
  previewColor: string; // Main color for UI preview
}

export enum QuestType {
  PLAY_GAMES = 'PLAY_GAMES',
  SCORE_POINTS = 'SCORE_POINTS',
  CLEAR_LINES = 'CLEAR_LINES',
}

export interface Quest {
  id: string;
  type: QuestType;
  target: number;
  current: number;
  reward: number;
  claimed: boolean;
  description: string;
}

export interface Transaction {
  id: string;
  date: number; // Timestamp
  amount: number;
  description: string;
  type: 'EARN' | 'SPEND';
}

export interface PlayerState {
  coins: number;
  inventory: string[]; // List of owned style IDs
  currentStyleId: string;
  lastLoginDate: string; // ISO date string YYYY-MM-DD
  dailyRewardClaimed: boolean;
  dailyQuests: Quest[];
  lastQuestDate: string; // To know when to reset quests
  transactions: Transaction[];
  stats: {
    gamesPlayed: number;
    totalLinesCleared: number;
    totalScore: number;
  };
}