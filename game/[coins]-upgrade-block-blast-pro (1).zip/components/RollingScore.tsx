import React from 'react';

interface DigitProps {
  value: string;
}

const Digit: React.FC<DigitProps> = ({ value }) => {
  return (
    <div className="relative h-8 w-5 overflow-hidden sm:h-10 sm:w-6">
      <div
        className="absolute left-0 top-0 flex flex-col transition-transform duration-500 ease-in-out"
        style={{ transform: `translateY(-${parseInt(value) * 10}%)` }}
      >
        {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => (
          <div key={n} className="flex h-8 w-5 items-center justify-center sm:h-10 sm:w-6">
            <span className="text-3xl font-black font-mono leading-none sm:text-4xl">{n}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

interface RollingScoreProps {
  score: number;
}

const RollingScore: React.FC<RollingScoreProps> = ({ score }) => {
  const digits = score.toString().split('');

  return (
    <div className="flex items-center justify-center overflow-hidden">
      {digits.map((digit, index) => {
        // Use power of 10 as key (0 for ones, 1 for tens, etc.)
        // This ensures that when the number grows (99 -> 100), the existing digits (ones, tens) 
        // keep their identity and animate correctly, while the new digit (hundreds) mounts.
        const powerOfTen = digits.length - 1 - index;
        return <Digit key={powerOfTen} value={digit} />;
      })}
    </div>
  );
};

export default RollingScore;