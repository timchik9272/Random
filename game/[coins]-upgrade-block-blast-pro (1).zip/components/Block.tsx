import React from 'react';
import { BlockShape } from '../types';

interface BlockProps {
  shape: BlockShape;
  size: number; // Size of a single cell in px
  className?: string;
  onPointerDown?: (e: React.PointerEvent) => void;
  style?: React.CSSProperties;
}

const Block: React.FC<BlockProps> = ({ shape, size, className, onPointerDown, style }) => {
  const rows = shape.matrix.length;
  const cols = shape.matrix[0].length;
  const width = cols * size;
  const height = rows * size;

  return (
    <div 
      className={`relative touch-none select-none ${className}`} 
      style={{ width, height, ...style }}
      onPointerDown={onPointerDown}
    >
      {shape.matrix.map((row, r) => (
        row.map((cell, c) => {
          if (!cell) return null;
          return (
            <div
              key={`${r}-${c}`}
              className="absolute border border-white/20 rounded-sm shadow-sm"
              style={{
                top: r * size,
                left: c * size,
                width: size,
                height: size,
                backgroundColor: shape.color,
                boxShadow: 'inset 0 2px 4px rgba(255,255,255,0.3), 0 2px 4px rgba(0,0,0,0.2)'
              }}
            />
          );
        })
      ))}
    </div>
  );
};

export default Block;