import { SoundManager } from '../types';

class WebAudioSoundManager implements SoundManager {
  private ctx: AudioContext | null = null;
  private muted: boolean = false;

  constructor() {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.ctx = new AudioContextClass();
      }
    } catch (e) {
      console.error("Web Audio API not supported");
    }
  }

  get isMuted() {
    return this.muted;
  }

  toggleMute() {
    this.muted = !this.muted;
  }

  private playTone(freq: number, type: OscillatorType, duration: number, startTime = 0) {
    if (this.muted || !this.ctx) return;
    if (this.ctx.state === 'suspended') this.ctx.resume();

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, this.ctx.currentTime + startTime);
    
    gain.gain.setValueAtTime(0.1, this.ctx.currentTime + startTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + startTime + duration);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(this.ctx.currentTime + startTime);
    osc.stop(this.ctx.currentTime + startTime + duration);
  }

  playPop() {
    this.playTone(400, 'sine', 0.1);
  }

  playClick() {
    this.playTone(800, 'triangle', 0.05);
  }

  playClear(combo: number) {
    if (this.muted || !this.ctx) return;
    const baseFreq = 400;
    // Play a chord based on combo count
    for(let i = 0; i < Math.min(combo, 5); i++) {
        this.playTone(baseFreq * (1 + i * 0.25), 'sine', 0.3, i * 0.05);
    }
  }

  playGameOver() {
    if (this.muted || !this.ctx) return;
    this.playTone(300, 'sawtooth', 0.3, 0);
    this.playTone(250, 'sawtooth', 0.3, 0.2);
    this.playTone(200, 'sawtooth', 0.5, 0.4);
  }
}

export const soundManager = new WebAudioSoundManager();